package jmvc;

import controllers.*;
import views.*;

/**
 *
 * @author haikalrafifas
 */
public class Navigator {
    public static void view(String pageIdentifier) {
        try {
            // Map the page identifier to controller and view classes
            Class<?> controllerClass = findControllerClass(pageIdentifier);
            Class<?> viewClass = findViewClass(controllerClass);

            // Create an instance of the controller
            java.lang.reflect.Constructor<?> controllerConstructor = controllerClass.getDeclaredConstructor();
            Object controllerInstance = controllerConstructor.newInstance();

            // Get the "setView" method of the controller
            java.lang.reflect.Method setViewMethod = controllerClass.getMethod("setView", viewClass);

            // Create an instance of the view
            java.lang.reflect.Constructor<?> viewConstructor = viewClass.getDeclaredConstructor(controllerClass);
            Object viewInstance = viewConstructor.newInstance(controllerInstance);

            // Invoke "setView" method with the view instance as an argument
            setViewMethod.invoke(controllerInstance, viewInstance);

        } catch (Exception e) {
            System.err.println(e);
        }
    }

    // A helper method to find the corresponding controller class for a given page identifier
    private static Class<?> findControllerClass(String pageIdentifier) {
        String controllerClassName = "controllers." + pageIdentifier.substring(0, 1).toUpperCase() + pageIdentifier.substring(1) + "Controller";
        try {
            return Class.forName(controllerClassName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Controller class not found: " + controllerClassName, e);
        }
    }

    // A helper method to find the corresponding view class for a given controller class
    private static Class<?> findViewClass(Class<?> controllerClass) {
        String controllerClassName = controllerClass.getSimpleName();
        String viewClassName = "views." + controllerClassName.replace("Controller", "Page");
        try {
            return Class.forName(viewClassName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("View class not found: " + viewClassName, e);
        }
    }
}
